Google Protocol Buffer Converter
================================

A `Converter` which uses [Protocol Buffer][1] binary serialization.


 [1]: https://developers.google.com/protocol-buffers/
