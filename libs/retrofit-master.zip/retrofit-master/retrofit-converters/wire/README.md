Wire Converter
==============

A `Converter` which uses [Wire][1] for protocol buffer-compatible serialization.

A default `Wire` instance will be created or one can be configured and passed to the
`WireConverter` construction to further control the serialization.


 [1]: https://github.com/square/wire
